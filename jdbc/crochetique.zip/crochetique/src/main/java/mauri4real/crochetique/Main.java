package mauri4real.crochetique;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        new CRUDselection().select();
    }
    public class InputUtil {
        public static final Scanner SCANNER = new Scanner(System.in);
    }
}
